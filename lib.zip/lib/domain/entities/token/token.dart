class Token {
  final String token;

  Token({
    required this.token,
  });
}
