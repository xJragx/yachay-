class Curso {
  final String nombre;
  final String imagenurl;
  final String profesor;

  Curso(
      {required this.nombre,
      required this.imagenurl,
      required this.profesor});
}
